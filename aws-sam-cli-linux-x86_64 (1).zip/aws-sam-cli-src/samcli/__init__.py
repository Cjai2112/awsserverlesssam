"""
SAM CLI version
"""

__version__ = "1.64.0"
